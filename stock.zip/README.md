# Pakistan Stock Exchange (PSX) Complete Historical Dataset

**Location:** `C:\Users\Admin\Desktop\05_PSX_Stock_Market_Dataset\`  
**Date Created:** 2026-10-08  
**Data Horizon:** 2016 to 2026 (~10 Years of Daily Trading History)  
**Total Data Points:** 239,461 daily OHLCV rows across 105 constituent companies  

---

## 📁 Repository Structure

```
05_PSX_Stock_Market_Dataset/
├── combined/
│   └── PSX_KSE100_Full_Historical_Daily.csv      # Single unified dataset of all 105 companies (239,461 rows)
├── stocks/                                       # 105 individual CSV files named by Full Company Name
│   ├── Abbott Laboratories (Pakistan) Limited.csv
│   ├── Allied Bank Limited.csv
│   ├── Engro Corporation Limited.csv
│   ├── Engro Fertilizers Limited.csv
│   ├── Habib Bank Limited.csv
│   ├── Lucky Cement Limited.csv
│   ├── Meezan Bank Limited.csv
│   ├── Oil & Gas Development Company Limited.csv
│   ├── Pakistan Petroleum Limited.csv
│   ├── Pakistan State Oil Company Limited.csv
│   ├── Systems Limited.csv
│   └── ... (all 105 companies)
├── indices/                                      # Index constituent holdings & weights
│   ├── KSE100_Constituents.csv                   # 100 benchmark companies
│   ├── KSE30_Constituents.csv                    # Top 30 liquid large-caps
│   ├── KMI30_Constituents.csv                    # Islamic Shariah-compliant 30 companies
│   └── ALLSHR_Constituents.csv                   # Complete 559 active exchange companies
├── metadata/                                     # Market structure & classifications
│   ├── PSX_Company_Name_To_Symbol_Mapping.csv    # Cross-reference of symbol, full name, and filename
│   ├── PSX_All_Listed_Companies.csv              # 1,038 listed equities, GEM, ETFs & debt securities
│   └── PSX_Sectors_Summary.csv                   # Sector listings & categorizations
├── download_psx_dataset.py                       # Python updater script to refresh or expand data
└── README.md                                     # Dataset documentation and ML integration guide
```

---

## 📊 Data Schema

Each stock file in `stocks/` contains clean daily time-series records:

| Column | Type | Description |
| :--- | :--- | :--- |
| `company_name` | String | Full corporate name (e.g. `Oil & Gas Development Company Limited`) |
| `symbol` | String | Exchange ticker symbol (e.g. `OGDC`, `ENGRO`, `SYS`) |
| `date` | Date (`YYYY-MM-DD`) | Trading session date (chronologically ordered ascending) |
| `open` | Float | Session opening price in PKR |
| `high` | Float | Highest recorded price during the session in PKR |
| `low` | Float | Lowest recorded price during the session in PKR |
| `close` | Float | Final closing price in PKR |
| `volume` | Integer | Total number of shares traded during the session |
| `is_anomaly`| Boolean | Automated flag identifying data validation alerts |

---

## 🤖 Machine Learning Quickstart (Python)

### 1. Load an Individual Stock for LSTM / ARIMA Forecasting
```python
import pandas as pd

# Load 10-year history of Systems Limited
df = pd.read_csv(r"C:\Users\Admin\Desktop\05_PSX_Stock_Market_Dataset\stocks\Systems Limited.csv")
df['date'] = pd.to_datetime(df['date'])
df.set_index('date', inplace=True)

print(df.tail())
```

### 2. Lookup Symbols by Company Name
```python
import pandas as pd

# Load mapping dictionary
mapping = pd.read_csv(r"C:\Users\Admin\Desktop\05_PSX_Stock_Market_Dataset\metadata\PSX_Company_Name_To_Symbol_Mapping.csv")
print(mapping.head())
```

---

## 🔄 Updating or Expanding Data
To refresh daily prices in the future, run:
```bash
python download_psx_dataset.py
```
This script caches existing data and queries the official exchange feeds to keep all datasets current.
