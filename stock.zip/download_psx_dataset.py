import os
import sys
import time
import re
import psxdata
import pandas as pd

# Fix Windows console UTF-8 encoding
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

project_dir = r"C:\Users\Admin\Desktop\antigravity\05_PSX_Stock_Market_Dataset"
stocks_dir = os.path.join(project_dir, "stocks")
indices_dir = os.path.join(project_dir, "indices")
metadata_dir = os.path.join(project_dir, "metadata")
combined_dir = os.path.join(project_dir, "combined")

for d in [stocks_dir, indices_dir, metadata_dir, combined_dir]:
    os.makedirs(d, exist_ok=True)

print("=== 1. Reading Index Constituents ===")
kse100_csv = os.path.join(indices_dir, "KSE100_Constituents.csv")
if os.path.exists(kse100_csv):
    kse100_df = pd.read_csv(kse100_csv)
    raw_symbols = kse100_df['symbol'].dropna().unique().tolist()
else:
    kse100_df = psxdata.indices('KSE100')
    kse100_df.to_csv(kse100_csv, index=False)
    raw_symbols = kse100_df['symbol'].dropna().unique().tolist()

# Normalize symbols: if symbol ends with XD, XB, XR (dividend flags), clean them
clean_symbols = []
for s in raw_symbols:
    cleaned = re.sub(r'(XD|XB|XR)$', '', s.strip())
    clean_symbols.append((s, cleaned))

# Also ensure top major PSX bluechips are present
bluechips = [
    "OGDC", "PPL", "PSO", "LUCK", "ENGRO", "FFC", "EFERT", "MCB", "HBL", "UBL",
    "MEBL", "SYS", "TRG", "HUBC", "KAPCO", "DGKC", "CHCC", "SEARL", "MARI", "ATRL",
    "INDU", "HCAR", "PAEL", "UNITY", "NATF", "FCCL", "MLCF", "KOHC", "NML", "ILP",
    "POL", "LOTCHEM", "EPCL", "PRL", "SNGP", "SSGC", "BAFL", "BAHL", "BIPL", "FABL"
]
for bc in bluechips:
    if not any(bc == c for _, c in clean_symbols):
        clean_symbols.append((bc, bc))

# Deduplicate by clean symbol
seen = set()
unique_symbols = []
for raw, clean in clean_symbols:
    if clean not in seen:
        seen.add(clean)
        unique_symbols.append((raw, clean))

print(f"Total Unique PSX Stocks to Download: {len(unique_symbols)}")

print("\n=== 2. Downloading Historical Daily OHLCV Data ===")
all_dfs = []
success_count = 0
skipped_count = 0

for i, (raw_sym, clean_sym) in enumerate(unique_symbols, 1):
    csv_path = os.path.join(stocks_dir, f"{clean_sym}.csv")
    
    # If already downloaded in previous run and valid, load from disk
    if os.path.exists(csv_path) and os.path.getsize(csv_path) > 500:
        try:
            df = pd.read_csv(csv_path)
            if not df.empty and 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date'])
                df_comb = df.copy()
                if 'symbol' not in df_comb.columns:
                    df_comb.insert(0, 'symbol', clean_sym)
                all_dfs.append(df_comb)
                success_count += 1
                print(f"[{i:03d}/{len(unique_symbols):03d}] Cached: {clean_sym} ({len(df)} rows)")
                continue
        except Exception:
            pass

    print(f"[{i:03d}/{len(unique_symbols):03d}] Fetching {clean_sym}...", end="", flush=True)
    df = None
    # Try clean symbol first, then raw symbol
    for try_sym in [clean_sym, raw_sym]:
        try:
            df = psxdata.stocks(try_sym)
            if df is not None and not df.empty:
                break
        except Exception:
            pass
    
    if df is not None and not df.empty:
        try:
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date'])
                df = df.sort_values(by='date').reset_index(drop=True)
            
            df.to_csv(csv_path, index=False)
            
            df_comb = df.copy()
            df_comb.insert(0, 'symbol', clean_sym)
            all_dfs.append(df_comb)
            
            success_count += 1
            min_date = df['date'].min().strftime('%Y-%m-%d') if 'date' in df.columns else 'N/A'
            max_date = df['date'].max().strftime('%Y-%m-%d') if 'date' in df.columns else 'N/A'
            print(f" SUCCESS ({len(df)} rows, {min_date} to {max_date})")
        except Exception as e:
            print(f" Error saving: {e}")
    else:
        print(" Empty / Not Available")
        skipped_count += 1
    
    time.sleep(0.05)

print(f"\nStock Download Summary: {success_count} successfully downloaded/cached, {skipped_count} skipped.")

print("\n=== 3. Creating Master Combined Historical Dataset ===")
if all_dfs:
    combined_master = pd.concat(all_dfs, ignore_index=True)
    combined_master_path = os.path.join(combined_dir, "PSX_KSE100_Full_Historical_Daily.csv")
    combined_master.to_csv(combined_master_path, index=False)
    print(f"Saved: {combined_master_path}")
    print(f"Total Rows: {len(combined_master):,} data points across {success_count} companies.")

print("\nAll operations completed successfully!")
